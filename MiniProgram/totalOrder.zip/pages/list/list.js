const fetch = require("../../module/service.js");
Page({
  data:{
    listmessage:[]
  },
  onLoad(){
    fetch('food/orderlist').then((res)=>{
      this.setData({
        listmessage:res.data.list
      })
    }).catch(()=>{
      wx.showToast({
        title: '数据请求错误',
        icon:'error',
        duration:500
      })
    })
  }
})