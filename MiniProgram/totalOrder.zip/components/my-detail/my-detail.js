// components/my-detail/my-detail.js
Component({
  properties: {
    definitedata:{
      type:[],
      value:null
    },
    definitegoods:{
      type:Number,
      value:0
    }
  }
})
